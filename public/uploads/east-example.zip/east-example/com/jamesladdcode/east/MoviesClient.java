package com.jamesladdcode.east;

interface MoviesClient {

	void add(Movie movie); 
}
