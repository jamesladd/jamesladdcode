package com.jamesladdcode.east;

interface MovieAction {

	void applyTo(Movie movie);
}
