package com.jamesladdcode.east;

interface MovieLister {

	void applyToTheMoviesDirectedBy(MovieAction action, String director);
}