package com.jamesladdcode.east;

interface MovieFinder {
	
	void findAllAndApply(MovieAction action);
}
